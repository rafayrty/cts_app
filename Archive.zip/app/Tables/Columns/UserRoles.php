<?php

namespace App\Tables\Columns;

use Filament\Tables\Columns\Column;

class UserRoles extends Column
{
    protected string $view = 'tables.columns.user-roles';
}
