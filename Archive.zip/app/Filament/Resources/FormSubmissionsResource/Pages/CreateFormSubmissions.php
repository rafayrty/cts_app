<?php

namespace App\Filament\Resources\FormSubmissionsResource\Pages;

use App\Filament\Resources\FormSubmissionsResource;
use Filament\Resources\Pages\CreateRecord;

class CreateFormSubmissions extends CreateRecord
{
    protected static string $resource = FormSubmissionsResource::class;
}
