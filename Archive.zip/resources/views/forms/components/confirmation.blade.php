<script>

alert("Hey you should delete the field"+@js($uuidToDelete))
</script>
