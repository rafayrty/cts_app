             <tr>
              <td class="es-p40 es-m-p30t es-m-p30b es-m-p20r es-m-p20l" align="left" bgcolor="#f9f9f9" style="background-color: #f9f9f9;border-radius: 0px 0px 20px 20px">
                <table style="margin:0 auto;">
                  <tr>
                    <td style="padding:4px 8px;"><a href="#" style="color:inherit;text-decoration:none">الرئيسية</a></td>
                    <td style="padding:4px 8px;"><a href="#" style="color:inherit;text-decoration:none">نبذة عن بصمتي</a></td>
                    <td style="padding:4px 8px;"><a href="#" style="color:inherit;text-decoration:none">الأسئلة الشائعة</a></td>
                    <td style="padding:4px 8px;"><a href="#" style="color:inherit;text-decoration:none">اتصل بنا</a></td>
                  </tr>
                </table>
               <table cellpadding="0" cellspacing="0" width="100%">
                 <tr>
                  <td width="560" align="center" valign="top">
                   <table cellpadding="0" cellspacing="0" width="100%" role="presentation">
                     <tr>
                      <td align="center" class="es-p15t es-m-txt-c" style="font-size:0">
                       <table cellpadding="0" cellspacing="0" class="es-table-not-adapt es-social" role="presentation">
                         <tr>
                          <td align="center" valign="top" class="es-p10r"><img title="Facebook" src="https://hoauwa.stripocdn.email/content/assets/img/social-icons/logo-black/facebook-logo-black.png" alt="Fb" height="32" width="32"/></td>
                          <td align="center" valign="top"><img title="Instagram" src="https://hoauwa.stripocdn.email/content/assets/img/social-icons/logo-black/instagram-logo-black.png" alt="Inst" height="32" width="32"/></td>
                         </tr>
                       </table></td>
                     </tr>
                     <tr>
                      <td align="center" class="es-p10t es-p10b" style="font-size: 0px;width:100px;">
                        <a target="_blank" href="hhttps://hoauwa.stripocdn.email/content/guids/CABINET_1b00f265289874424dda3ae6dbc2c3356fb34a7f66de82d1ffa602e30734a581/images/blue.pngttps://basmti.com">
                          <img class="adapt-img" src="https://hoauwa.stripocdn.email/content/guids/CABINET_1b00f265289874424dda3ae6dbc2c3356fb34a7f66de82d1ffa602e30734a581/images/blue.png" alt style="display: block" width="120" height="39" layout="responsive">
                        </a></td>
                     </tr>
                     <tr>
                      <td align="center" class="es-p15t es-m-txt-l"><p style="color: #1b2d45;line-height: 150%">Copyright 2023 BASMTI . All rights reserved</p></td>
                     </tr>
                   </table></td>
                 </tr>
               </table></td>
             </tr>
