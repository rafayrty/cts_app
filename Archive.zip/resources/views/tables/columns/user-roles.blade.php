<div>
  {{str_replace("_"," ",ucfirst($getRecord()->getRoleNames()->first()))}}
</div>
