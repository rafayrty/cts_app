<div class="flex items-center justify-between">
  <div class="flex flex-col items-center justify-center">
      <h1 class="font-bold text-lg">Orders Pending</h1>
      <p class="text-lg">{{$order_pending}}</p>
  </div>

  <div class="flex flex-col items-center justify-center">
      <h1 class="font-bold text-lg">Orders Printing</h1>
      <p class="text-lg">{{$order_printing}}</p>
  </div>

  <div class="flex flex-col items-center justify-center">
      <h1 class="font-bold text-lg">Orders Completed</h1>
      <p class="text-lg">{{$order_completed}}</p>
  </div>

</div>
